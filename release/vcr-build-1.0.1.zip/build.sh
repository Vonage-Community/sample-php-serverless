#!/bin/bash
composer install